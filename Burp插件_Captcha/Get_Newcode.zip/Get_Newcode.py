#!/usr/bin/env python
#coding:gbk
from burp import IBurpExtender
from burp import IIntruderPayloadGeneratorFactory
from burp import IIntruderPayloadGenerator
import base64
import json
import re
import urllib2
import ssl

class BurpExtender(IBurpExtender, IIntruderPayloadGeneratorFactory):
    def registerExtenderCallbacks(self, callbacks):
        callbacks.registerIntruderPayloadGeneratorFactory(self)
        callbacks.setExtensionName("getnewcode")

    def getGeneratorName(self):
        return "getnewcode"

    def createNewInstance(self, attack):
        return getnewcode(attack)

class getnewcode(IIntruderPayloadGenerator):
    def __init__(self, attack):
        tem = "".join(chr(abs(x)) for x in attack.getRequestTemplate())         
        ssl._create_default_https_context = ssl._create_unverified_context 
        getnewcode = 'https://www.ikea.cn/api-ciam-host/idaas/api/bff/v1.2/ciam/user/change_phone_or_email/obtain_code_v2'
        print getnewcode+'\n'
        self.getnewcode = getnewcode
        self.max = 1
        self.num = 0
        self.attack = attack

    def hasMorePayloads(self):
        if self.num == self.max:
            return False
        else:
            return True

    def getNextPayload(self, payload):
        getnewcode_url = self.getnewcode
        request_body = '{"email":"chenwei.gu@ingka.com","type":"EMAIL","challenge":"bac48c9271bd15bb75ff3d32ffaaf9af48","validate":"9f2e386fcf823e22d16ad819979103ef","seccode":"9f2e386fcf823e22d16ad819979103ef|jordan"}'
        request_header = {"Host": "www.ikea.cn","Accept": "application/json, text/plain, */*","Content-Type": "application/json;charset=utf-8","Content-Length": "198","Source": "NEW_WEB","Authorization": "Bearer eyJhbGciOiJSUzI1NiIsImtpZCI6IjdlOGJiODlkNDNiNzk1ZDQ4MzZlYjVkZGFjNjJiMWIyUEJSMlFtV3Z4SG8ifQ.eyJzdWIiOiIyMzkxMzIyMzQ3NTEyOTQzMzM3IiwiZ3RwIjoicGFzc3dvcmQiLCJ1bmlvbklkIjoib21ia3QxRVlLTXVqMXh6YWctYTFwWGxDUjdBbyIsImNvb2tpZSI6IiIsInVzZXJfbmFtZSI6IlIyMDIxMDEyNzUwNTU1NyIsImlzcyI6IkNJQU0iLCJwYXJ0eVVJZCI6IjE4QjBFRENCLUY0RDUtMTFlYS04Q0NFLTAwNTA1NjkzNTJGOSIsImNsaWVudF9pZCI6IjdlOGJiODlkNDNiNzk1ZDQ4MzZlYjVkZGFjNjJiMWIyUEJSMlFtV3Z4SG8iLCJmYW1pbHlJZCI6IjYyNzU5ODAzMzg3NzE3NzE0OTAiLCJhdWQiOlsiYXBwX2FwaV9yZXNvdXJjZSIsImJmZl9hcGlfcmVzb3VyY2UiXSwiZ3JhbnRfdHlwZSI6InBhc3N3b3JkIiwidXNlcl9pZCI6IjBhNDU4M2M4ZGIzMmE0MzFlZmNiOGJiNjU1MGNiYTE2aDBFWVpiOTV0cFUiLCJwaG9uZSI6IjEzNTI0OTgzNzY4IiwiYXpwIjoiIiwic2NvcGUiOlsicmVhZCJdLCJleHAiOjE2MjYyNDU0ODksImp0aSI6IjdhYTQ3YTU0LTBmYzAtNDY5Mi1iMmRmLTczNTIzZDI2OGJiZSIsImVtYWlsIjoidXJleS5sb3VAaW5na2EuaWtlYS5jb20iLCJtZW1iZXJJZCI6IjI1NjQ2OTkyNjMiLCJpYXQiOjE2MjU2NDA2ODksIm5iZiI6MTYyNTY0MDYyOX0.ZUkEscgkPnc6QBCTMmsdOACIuW8reDaEWvPP3mmTMd0PFBtXxvk7CbrCQEDTWl266Trz8zf_fyNfhwVRoL2uyY9V3lnvNnWRNUBzHMIeCWnW48Eb39fujAOHHa57bjS6AjjK757Tw0tossUpYoBh55KGs8dOi0_fOePEjmFAH6g91ZneilAXMXYNusEhGt7PtFJ7-Vp9TtjmrE-T_KpLNyI6tRrGyoROcEwz6aogwDYkGoh0nBRV35w4iatkwC8AwJuA1pmNmzra4U0VJ_mq67bKwmkGuAMeUiMsH9rf7t2evH5vBw8gIo18PTkaRee30eRPqXp_kYsE6scZbbpcvg","Connection": "close"}
        request = urllib2.Request(getnewcode_url,headers=request_header,data=request_body)
        response = urllib2.urlopen(request).read()
        codeId = json.loads(response)["data"]["updateId"]
        return codeId

    def reset(self):
        self.num = 0
        return